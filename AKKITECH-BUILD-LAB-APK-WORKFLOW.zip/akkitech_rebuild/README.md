# AKKITECH BUILD LAB

AKKITECH BUILD LAB is a React + Vite application with an Express API server.

## Build the Android APK with GitHub Actions

1. Upload **all files and folders inside this ZIP** to the root of a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build AKKITECH BUILD LAB APK**.
4. Tap **Run workflow** and confirm.
5. When the run finishes successfully, open the run and download the artifact named `akkitech-build-lab-debug-apk`.

The workflow creates a **debug APK** for installing/testing. It is not a Play Store release-signed APK.

## Important backend limitation

This APK packages the web interface. The current app also calls Express endpoints such as `/api/engine/status`, `/api/jobs`, and `/api/engine/test-runner`. Those endpoints are provided by `server.ts` and are **not hosted inside the static Capacitor APK**. Therefore, APK installation may work, but backend-dependent build/diagnostics/history features will not work until the Express server is deployed to a reachable HTTPS host and the app is configured to use that server URL.

Do not enter private API keys into a public repository. Configure secrets on the backend host instead.

## Run the web app locally

- Install Node.js 22 or newer.
- Run `npm install`.
- Configure `.env.local` if required by your deployment.
- Run `npm run dev`.

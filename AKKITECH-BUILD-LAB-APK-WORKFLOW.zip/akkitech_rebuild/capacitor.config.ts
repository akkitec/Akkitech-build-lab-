import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.akkitech.buildlab',
  appName: 'AKKITECH BUILD LAB',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#071426'
  }
};

export default config;

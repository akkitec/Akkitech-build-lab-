# APK build notes

- Added Capacitor Android packaging configuration for `com.akkitech.buildlab`.
- Added `.github/workflows/build-apk.yml` to build a debug APK on GitHub Actions.
- The workflow creates the native Android project in CI, syncs the Vite `dist` output, runs Gradle, and uploads the APK artifact.
- This produces an installable test APK, not a release-signed Play Store package.
- The Express backend in `server.ts` remains a separate deployment requirement. The APK alone does not host that server.

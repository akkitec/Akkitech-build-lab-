import React, { useState } from 'react';
import { X, Cpu, CheckCircle2, AlertTriangle, RefreshCw, Send, Server, Wrench } from 'lucide-react';
import { EngineStatus, Language } from '../types';
import { translations } from '../utils/translations';

interface DiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  status: EngineStatus | null;
  currentLang: Language;
  onRefresh: () => void;
  onRunnerConfigured: (url: string) => void;
}

export const DiagnosticsModal: React.FC<DiagnosticsModalProps> = ({
  isOpen,
  onClose,
  status,
  currentLang,
  onRefresh,
  onRunnerConfigured
}) => {
  const t = translations[currentLang];
  const [workerUrl, setWorkerUrl] = useState('');
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  if (!isOpen) return null;

  const handleTestConnection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!workerUrl) return;

    setIsTesting(true);
    setTestResult(null);

    try {
      const res = await fetch('/api/engine/test-runner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: workerUrl })
      });
      const data = await res.json();
      setTestResult(data);
      if (data.success) {
        onRunnerConfigured(workerUrl);
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        message: err.message || 'Worker server unreachable'
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-white/10 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-5">
          <div className="flex items-center gap-2.5">
            <Cpu className="w-5 h-5 text-blue-400" />
            <h3 className="text-base sm:text-lg font-bold text-white">
              {t.diagTitle}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="space-y-4">
          <p className="text-xs text-slate-400 leading-relaxed">
            {t.diagDesc}
          </p>

          {/* Tools Inspection Grid */}
          <div className="bg-slate-950/80 rounded-xl p-4 border border-white/5 space-y-3 font-mono text-xs">
            
            {/* Java JDK */}
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-slate-400 font-sans font-medium">{t.javaJdk}</span>
                <p className="text-slate-300 text-[11px] mt-0.5">
                  {status?.tools.jdk.version || 'Probing...'}
                </p>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase shrink-0 ${
                status?.tools.jdk.installed
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                  : 'bg-rose-950 text-rose-400 border border-rose-500/30'
              }`}>
                {status?.tools.jdk.installed ? 'Available' : 'Missing'}
              </span>
            </div>

            <div className="h-px bg-white/5" />

            {/* Android SDK */}
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-slate-400 font-sans font-medium">{t.androidSdkTool}</span>
                <p className="text-slate-300 text-[11px] mt-0.5 break-all">
                  {status?.tools.androidSdk.path || 'Not configured ($ANDROID_HOME)'}
                </p>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase shrink-0 ${
                status?.tools.androidSdk.installed
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                  : 'bg-rose-950 text-rose-400 border border-rose-500/30'
              }`}>
                {status?.tools.androidSdk.installed ? 'Available' : 'Missing'}
              </span>
            </div>

            <div className="h-px bg-white/5" />

            {/* Gradle */}
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-slate-400 font-sans font-medium">{t.gradleTool}</span>
                <p className="text-slate-300 text-[11px] mt-0.5">
                  {status?.tools.gradle.version || 'Not found'}
                </p>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase shrink-0 ${
                status?.tools.gradle.installed
                  ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                  : 'bg-rose-950 text-rose-400 border border-rose-500/30'
              }`}>
                {status?.tools.gradle.installed ? 'Available' : 'Missing'}
              </span>
            </div>

          </div>

          {/* Connect Remote Worker Form */}
          <div className="pt-2">
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              {t.workerUrlLabel}
            </label>
            <form onSubmit={handleTestConnection} className="flex gap-2">
              <input
                type="url"
                value={workerUrl}
                onChange={(e) => setWorkerUrl(e.target.value)}
                placeholder="https://runner.yourcompany.com or http://localhost:8080"
                className="flex-1 bg-slate-950 border border-white/10 rounded-lg px-3 py-2 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
              <button
                type="submit"
                disabled={isTesting || !workerUrl}
                className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-lg shrink-0 flex items-center gap-1.5 transition-colors"
              >
                {isTesting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                <span>{t.testWorker}</span>
              </button>
            </form>

            {testResult && (
              <div className={`mt-2 p-2.5 rounded-lg text-xs font-medium border flex items-center gap-2 ${
                testResult.success
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                  : 'bg-rose-950/60 border-rose-500/40 text-rose-300'
              }`}>
                {testResult.success ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertTriangle className="w-4 h-4 shrink-0" />}
                <span>{testResult.message}</span>
              </div>
            )}

            <p className="text-[11px] text-slate-500 mt-2">
              {t.workerTip}
            </p>
          </div>

        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
          <button
            onClick={onRefresh}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Re-scan Environment</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg"
          >
            {t.close}
          </button>
        </div>

      </div>
    </div>
  );
};

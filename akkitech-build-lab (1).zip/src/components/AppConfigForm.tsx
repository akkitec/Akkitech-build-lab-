import React from 'react';
import { Settings2, Smartphone, Shield, Package, Layers, RefreshCcw, Check, Sparkles } from 'lucide-react';
import { BuildConfig, Language, TargetFormat } from '../types';
import { translations } from '../utils/translations';

interface AppConfigFormProps {
  currentLang: Language;
  config: BuildConfig;
  onChangeConfig: (updates: Partial<BuildConfig>) => void;
  onSubmitBuild: () => void;
  onReset: () => void;
  isBuilding: boolean;
  hasFile: boolean;
}

export const AppConfigForm: React.FC<AppConfigFormProps> = ({
  currentLang,
  config,
  onChangeConfig,
  onSubmitBuild,
  onReset,
  isBuilding,
  hasFile
}) => {
  const t = translations[currentLang];

  const handleTargetChange = (format: TargetFormat) => {
    onChangeConfig({ targetFormat: format });
  };

  const handlePermissionToggle = (perm: string) => {
    const current = new Set(config.permissions);
    if (current.has(perm)) {
      current.delete(perm);
    } else {
      current.add(perm);
    }
    onChangeConfig({ permissions: Array.from(current) });
  };

  // Basic package ID validity check
  const isPackageValid = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/i.test(config.packageId);

  return (
    <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-5 sm:p-6 shadow-xl mb-6">
      <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-5">
        <div className="flex items-center gap-2.5">
          <Settings2 className="w-5 h-5 text-blue-400" />
          <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
            {t.buildConfiguration}
          </h3>
        </div>
        <button
          type="button"
          onClick={onReset}
          className="text-xs text-slate-400 hover:text-slate-200 transition-colors flex items-center gap-1"
        >
          <RefreshCcw className="w-3.5 h-3.5" />
          {t.btnReset}
        </button>
      </div>

      <form onSubmit={(e) => { e.preventDefault(); onSubmitBuild(); }} className="space-y-6">

        {/* 1. Target Format Selection (APK Debug / APK Release / AAB) */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2.5">
            {t.targetFormat}
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            
            {/* APK Debug */}
            <button
              type="button"
              onClick={() => handleTargetChange('apk_debug')}
              className={`p-3.5 rounded-xl border text-left transition-all ${
                config.targetFormat === 'apk_debug'
                  ? 'bg-blue-950/60 border-blue-500 shadow-md shadow-blue-500/10'
                  : 'bg-slate-950/40 border-white/5 hover:border-white/15'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-sm font-bold ${config.targetFormat === 'apk_debug' ? 'text-blue-300' : 'text-slate-200'}`}>
                  {t.apkDebug}
                </span>
                {config.targetFormat === 'apk_debug' && (
                  <Check className="w-4 h-4 text-blue-400" />
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                {t.apkDebugDesc}
              </p>
            </button>

            {/* APK Release */}
            <button
              type="button"
              onClick={() => handleTargetChange('apk_release')}
              className={`p-3.5 rounded-xl border text-left transition-all ${
                config.targetFormat === 'apk_release'
                  ? 'bg-blue-950/60 border-blue-500 shadow-md shadow-blue-500/10'
                  : 'bg-slate-950/40 border-white/5 hover:border-white/15'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-sm font-bold ${config.targetFormat === 'apk_release' ? 'text-blue-300' : 'text-slate-200'}`}>
                  {t.apkRelease}
                </span>
                {config.targetFormat === 'apk_release' && (
                  <Check className="w-4 h-4 text-blue-400" />
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                {t.apkReleaseDesc}
              </p>
            </button>

            {/* AAB App Bundle */}
            <button
              type="button"
              onClick={() => handleTargetChange('aab')}
              className={`p-3.5 rounded-xl border text-left transition-all ${
                config.targetFormat === 'aab'
                  ? 'bg-blue-950/60 border-blue-500 shadow-md shadow-blue-500/10'
                  : 'bg-slate-950/40 border-white/5 hover:border-white/15'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-sm font-bold ${config.targetFormat === 'aab' ? 'text-blue-300' : 'text-slate-200'}`}>
                  {t.aabRelease}
                </span>
                {config.targetFormat === 'aab' && (
                  <Check className="w-4 h-4 text-blue-400" />
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                {t.aabReleaseDesc}
              </p>
            </button>

          </div>
        </div>

        {/* 2. Core Identifiers: App Name & Package ID */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              {t.appName} <span className="text-blue-400">*</span>
            </label>
            <input
              type="text"
              required
              value={config.appName}
              onChange={(e) => onChangeConfig({ appName: e.target.value })}
              placeholder={t.appNamePlaceholder}
              className="w-full bg-slate-950 border border-white/10 rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-medium text-slate-300">
                {t.packageId} <span className="text-blue-400">*</span>
              </label>
              {!isPackageValid && (
                <span className="text-[11px] text-amber-400">Invalid format</span>
              )}
            </div>
            <input
              type="text"
              required
              value={config.packageId}
              onChange={(e) => onChangeConfig({ packageId: e.target.value.toLowerCase().replace(/[^a-z0-9_.]/g, '') })}
              placeholder={t.packageIdPlaceholder}
              className={`w-full bg-slate-950 border rounded-lg px-3.5 py-2.5 text-sm font-mono text-white placeholder-slate-500 focus:outline-none transition-colors ${
                isPackageValid ? 'border-white/10 focus:border-blue-500' : 'border-amber-500/50 focus:border-amber-500'
              }`}
            />
            <span className="text-[11px] text-slate-500 mt-1 block">
              {t.packageIdHint}
            </span>
          </div>
        </div>

        {/* 3. Versions & SDK Targets */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              {t.versionName}
            </label>
            <input
              type="text"
              value={config.versionName}
              onChange={(e) => onChangeConfig({ versionName: e.target.value })}
              placeholder={t.versionNamePlaceholder}
              className="w-full bg-slate-950 border border-white/10 rounded-lg px-3 py-2 text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              {t.versionCode}
            </label>
            <input
              type="number"
              min={1}
              value={config.versionCode}
              onChange={(e) => onChangeConfig({ versionCode: parseInt(e.target.value) || 1 })}
              placeholder={t.versionCodePlaceholder}
              className="w-full bg-slate-950 border border-white/10 rounded-lg px-3 py-2 text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              {t.minSdk}
            </label>
            <select
              value={config.minSdk}
              onChange={(e) => onChangeConfig({ minSdk: parseInt(e.target.value) })}
              className="w-full bg-slate-950 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500"
            >
              <option value={21}>API 21 (Android 5.0)</option>
              <option value={24}>API 24 (Android 7.0 - Recommended)</option>
              <option value={26}>API 26 (Android 8.0)</option>
              <option value={29}>API 29 (Android 10.0)</option>
              <option value={33}>API 33 (Android 13.0)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              {t.targetSdk}
            </label>
            <select
              value={config.targetSdk}
              onChange={(e) => onChangeConfig({ targetSdk: parseInt(e.target.value) })}
              className="w-full bg-slate-950 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500"
            >
              <option value={34}>API 34 (Android 14 - Play Store Spec)</option>
              <option value={35}>API 35 (Android 15)</option>
            </select>
          </div>
        </div>

        {/* 4. Orientation & Acceleration */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              {t.orientation}
            </label>
            <select
              value={config.orientation}
              onChange={(e) => onChangeConfig({ orientation: e.target.value as any })}
              className="w-full bg-slate-950 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-blue-500"
            >
              <option value="unspecified">{t.orientationAuto}</option>
              <option value="portrait">{t.orientationPortrait}</option>
              <option value="landscape">{t.orientationLandscape}</option>
            </select>
          </div>

          <div className="flex items-center gap-3 pt-6">
            <label className="relative flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-300">
              <input
                type="checkbox"
                checked={config.hardwareAcceleration}
                onChange={(e) => onChangeConfig({ hardwareAcceleration: e.target.checked })}
                className="w-4 h-4 rounded text-blue-600 bg-slate-950 border-white/20 focus:ring-blue-500"
              />
              <span>{t.hardwareAcceleration}</span>
            </label>
          </div>
        </div>

        {/* 5. WebView Features (When Type is Web App) */}
        {config.projectType === 'web_app' && (
          <div className="pt-2">
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2.5">
              {t.webviewFeatures}
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 bg-slate-950/60 p-3.5 rounded-xl border border-white/5">
              
              <label className="flex items-center gap-2.5 cursor-pointer text-xs text-slate-300 hover:text-white">
                <input
                  type="checkbox"
                  checked={config.pullToRefresh}
                  onChange={(e) => onChangeConfig({ pullToRefresh: e.target.checked })}
                  className="w-4 h-4 rounded text-blue-600 bg-slate-950 border-white/20 focus:ring-blue-500"
                />
                <span>{t.pullToRefresh}</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer text-xs text-slate-300 hover:text-white">
                <input
                  type="checkbox"
                  checked={config.enableOfflineCache}
                  onChange={(e) => onChangeConfig({ enableOfflineCache: e.target.checked })}
                  className="w-4 h-4 rounded text-blue-600 bg-slate-950 border-white/20 focus:ring-blue-500"
                />
                <span>{t.enableOfflineCache}</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer text-xs text-slate-300 hover:text-white">
                <input
                  type="checkbox"
                  checked={config.allowFileUploads}
                  onChange={(e) => onChangeConfig({ allowFileUploads: e.target.checked })}
                  className="w-4 h-4 rounded text-blue-600 bg-slate-950 border-white/20 focus:ring-blue-500"
                />
                <span>{t.allowFileUploads}</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer text-xs text-slate-300 hover:text-white">
                <input
                  type="checkbox"
                  checked={config.allowCamera}
                  onChange={(e) => onChangeConfig({ allowCamera: e.target.checked })}
                  className="w-4 h-4 rounded text-blue-600 bg-slate-950 border-white/20 focus:ring-blue-500"
                />
                <span>{t.allowCamera}</span>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer text-xs text-slate-300 hover:text-white sm:col-span-2">
                <input
                  type="checkbox"
                  checked={config.enableDeepLinks}
                  onChange={(e) => onChangeConfig({ enableDeepLinks: e.target.checked })}
                  className="w-4 h-4 rounded text-blue-600 bg-slate-950 border-white/20 focus:ring-blue-500"
                />
                <span>{t.enableDeepLinks}</span>
              </label>

            </div>
          </div>
        )}

        {/* 6. Android Manifest Permissions Checklist */}
        <div className="pt-2">
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2.5">
            {t.androidPermissions}
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-950/60 p-3.5 rounded-xl border border-white/5 text-xs text-slate-300">
            
            {[
              { id: 'INTERNET', label: t.permInternet, mandatory: true },
              { id: 'ACCESS_NETWORK_STATE', label: t.permNetworkState, mandatory: true },
              { id: 'CAMERA', label: t.permCamera, mandatory: false },
              { id: 'READ_EXTERNAL_STORAGE', label: t.permStorage, mandatory: false },
              { id: 'ACCESS_FINE_LOCATION', label: t.permLocation, mandatory: false },
              { id: 'RECORD_AUDIO', label: t.permAudio, mandatory: false }
            ].map(perm => (
              <label key={perm.id} className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={perm.mandatory || config.permissions.includes(perm.id)}
                  disabled={perm.mandatory}
                  onChange={() => handlePermissionToggle(perm.id)}
                  className="w-4 h-4 rounded text-blue-600 bg-slate-950 border-white/20 focus:ring-blue-500 disabled:opacity-60"
                />
                <span className={perm.mandatory ? 'text-slate-400 font-mono text-[11px]' : 'text-slate-200'}>
                  {perm.label}
                </span>
              </label>
            ))}

          </div>
        </div>

        {/* 7. Action CTA Button */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isBuilding || !hasFile || !isPackageValid}
            className={`w-full py-3.5 px-6 rounded-xl font-bold text-sm sm:text-base text-white shadow-lg transition-all flex items-center justify-center gap-2 ${
              isBuilding
                ? 'bg-blue-800 opacity-80 cursor-wait'
                : !hasFile || !isPackageValid
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-white/5'
                : 'bg-blue-600 hover:bg-blue-500 shadow-blue-600/30 active:scale-[0.99]'
            }`}
          >
            {isBuilding ? (
              <>
                <RefreshCcw className="w-5 h-5 animate-spin" />
                <span>{t.btnBuilding}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>{t.btnStartBuild}</span>
              </>
            )}
          </button>
          {!hasFile && (
            <p className="text-center text-xs text-slate-400 mt-2">
              Please upload or load a sample ZIP archive above first.
            </p>
          )}
        </div>

      </form>
    </div>
  );
};

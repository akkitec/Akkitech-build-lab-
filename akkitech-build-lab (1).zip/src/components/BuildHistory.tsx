import React, { useState } from 'react';
import { History, Download, Terminal, ChevronDown, ChevronUp, FileArchive } from 'lucide-react';
import { BuildJob, Language } from '../types';
import { translations } from '../utils/translations';

interface BuildHistoryProps {
  currentLang: Language;
  jobs: BuildJob[];
  onDownloadProjectZip: (job: BuildJob) => void;
}

export const BuildHistory: React.FC<BuildHistoryProps> = ({
  currentLang,
  jobs,
  onDownloadProjectZip
}) => {
  const t = translations[currentLang];
  const [expandedJobId, setExpandedJobId] = useState<string | null>(null);

  const toggleJobLogs = (id: string) => {
    setExpandedJobId(expandedJobId === id ? null : id);
  };

  return (
    <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-5 sm:p-6 shadow-xl mb-6">
      <div className="flex items-center gap-2.5 border-b border-white/10 pb-4 mb-4">
        <History className="w-5 h-5 text-blue-400" />
        <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
          {t.historyTitle}
        </h3>
      </div>

      {jobs.length === 0 ? (
        <div className="py-12 text-center">
          <div className="w-12 h-12 rounded-2xl bg-slate-800 text-slate-500 mx-auto flex items-center justify-center mb-3">
            <FileArchive className="w-6 h-6" />
          </div>
          <p className="text-sm text-slate-400 max-w-sm mx-auto">
            {t.noBuildsYet}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {jobs.map((job) => {
            const isExpanded = expandedJobId === job.id;
            const dateStr = new Date(job.createdAt).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
              second: '2-digit'
            });

            return (
              <div
                key={job.id}
                className="bg-slate-950/70 border border-white/5 hover:border-white/10 rounded-xl p-4 transition-all"
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-sm text-white">
                        {job.appName}
                      </span>
                      <span className="text-xs font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-white/5">
                        {job.packageId}
                      </span>
                      <span className="text-[11px] font-mono text-blue-400 bg-blue-950/60 px-2 py-0.5 rounded border border-blue-500/20">
                        {job.targetFormat.toUpperCase()}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 text-xs text-slate-400">
                      <span>{dateStr}</span>
                      <span aria-hidden="true">·</span>
                      <span>{job.projectType === 'web_app' ? 'Web App' : 'Android Studio'}</span>
                      <span aria-hidden="true">·</span>
                      <span>v{job.versionName} ({job.versionCode})</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    <button
                      type="button"
                      onClick={() => toggleJobLogs(job.id)}
                      className="px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded-lg border border-white/10 flex items-center gap-1"
                    >
                      <Terminal className="w-3.5 h-3.5" />
                      <span>{t.viewLogs}</span>
                      {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>

                    <button
                      type="button"
                      onClick={() => onDownloadProjectZip(job)}
                      className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>{t.downloadSource}</span>
                    </button>
                  </div>
                </div>

                {isExpanded && (
                  <div className="mt-3 pt-3 border-t border-white/5">
                    <div className="bg-slate-950 rounded-lg p-3 font-mono text-xs text-slate-300 max-h-48 overflow-y-auto space-y-1">
                      {job.logs.map((log, idx) => (
                        <div key={idx} className="truncate">
                          {log}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

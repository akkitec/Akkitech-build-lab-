import React from 'react';
import { AlertTriangle, CheckCircle2, Terminal, Info, ExternalLink } from 'lucide-react';
import { EngineStatus, Language } from '../types';
import { translations } from '../utils/translations';

interface EngineStatusBannerProps {
  status: EngineStatus | null;
  currentLang: Language;
  onOpenDiagnostics: () => void;
  onOpenRunnerSetup: () => void;
}

export const EngineStatusBanner: React.FC<EngineStatusBannerProps> = ({
  status,
  currentLang,
  onOpenDiagnostics,
  onOpenRunnerSetup
}) => {
  const t = translations[currentLang];
  const isConnected = status?.connected ?? false;

  return (
    <div className="w-full mb-6">
      {!isConnected ? (
        <div className="bg-gradient-to-r from-amber-950/40 via-slate-900/80 to-blue-950/40 border border-amber-500/30 rounded-xl p-4 sm:p-5 shadow-lg">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 shrink-0 mt-0.5 sm:mt-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-semibold text-amber-300 tracking-wide">
                    {t.engineDisconnected}
                  </h4>
                  <span className="text-[11px] font-mono text-amber-400/80 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500/20">
                    Host: Container Sandbox
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-300 mt-1 leading-relaxed max-w-3xl">
                  {t.engineDisconnectedDesc}{' '}
                  <span className="text-slate-400">
                    AKKITECH BUILD LAB operates with 100% honest transparency: you can generate & download the complete, fully-configured <strong>Android Studio Project ZIP</strong>, or run it through our included <strong>GitHub Actions 1-Click Builder</strong>.
                  </span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
              <button
                onClick={onOpenDiagnostics}
                className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-white/10 rounded-lg transition-colors whitespace-nowrap"
              >
                {t.viewDiagnostics}
              </button>
              <button
                onClick={onOpenRunnerSetup}
                className="px-3 py-1.5 text-xs font-semibold text-amber-200 hover:text-white bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/30 rounded-lg transition-colors whitespace-nowrap"
              >
                Connect Runner
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-emerald-950/30 border border-emerald-500/30 rounded-xl p-4 shadow-lg flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-emerald-300">
                {t.engineConnected}
              </h4>
              <p className="text-xs text-slate-300 mt-0.5">
                Android SDK & Gradle compiler are ready. Direct APK and AAB generation enabled.
              </p>
            </div>
          </div>
          <button
            onClick={onOpenDiagnostics}
            className="px-3 py-1.5 text-xs font-medium text-emerald-300 hover:text-emerald-200 bg-emerald-950/60 border border-emerald-500/40 rounded-lg"
          >
            {t.viewDiagnostics}
          </button>
        </div>
      )}
    </div>
  );
};

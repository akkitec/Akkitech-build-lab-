import React, { useRef, useState } from 'react';
import { UploadCloud, FileArchive, CheckCircle2, AlertCircle, FileText, ChevronDown, ChevronUp, Sparkles, RefreshCw } from 'lucide-react';
import { DetectedProjectInfo, Language, ProjectType } from '../types';
import { translations } from '../utils/translations';
import { createSampleWebAppZip, createSampleAndroidProjectZip } from '../utils/zipAnalyzer';

interface ProjectUploadZoneProps {
  currentLang: Language;
  onFileLoaded: (file: File | Blob, fileName: string, detected: DetectedProjectInfo) => void;
  activeProjectType: ProjectType;
  onChangeProjectType: (type: ProjectType) => void;
  detectedInfo: DetectedProjectInfo | null;
  uploadedFileName: string | null;
  isAnalyzing: boolean;
}

export const ProjectUploadZone: React.FC<ProjectUploadZoneProps> = ({
  currentLang,
  onFileLoaded,
  activeProjectType,
  onChangeProjectType,
  detectedInfo,
  uploadedFileName,
  isAnalyzing
}) => {
  const t = translations[currentLang];
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const [showFileList, setShowFileList] = useState(false);
  const [isLoadingSample, setIsLoadingSample] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      processFile(file);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      processFile(file);
    }
  };

  const processFile = async (file: File) => {
    // Dynamically analyze with zipAnalyzer in parent handler
    onFileLoaded(file, file.name, {
      type: 'unknown',
      confidence: 0,
      files: [],
      hasIndexHtml: false,
      hasBuildGradle: false,
      hasAndroidManifest: false,
      totalFiles: 0,
      totalSizeBytes: file.size,
      summary: 'Analyzing...'
    });
  };

  const handleLoadSample = async (type: 'web' | 'android') => {
    setIsLoadingSample(true);
    try {
      if (type === 'web') {
        const sampleBlob = await createSampleWebAppZip();
        onChangeProjectType('web_app');
        onFileLoaded(sampleBlob, 'sample-web-app.zip', {
          type: 'web_app',
          confidence: 96,
          files: ['index.html', 'app.css', 'manifest.json'],
          hasIndexHtml: true,
          hasBuildGradle: false,
          hasAndroidManifest: false,
          detectedTitle: 'AKKITECH Nova',
          detectedPackage: 'com.akkitech.nova',
          detectedVersion: '1.0.0',
          totalFiles: 3,
          totalSizeBytes: sampleBlob.size,
          summary: 'Web Application detected with entry point "index.html".'
        });
      } else {
        const sampleBlob = await createSampleAndroidProjectZip();
        onChangeProjectType('android_studio');
        onFileLoaded(sampleBlob, 'sample-android-gradle.zip', {
          type: 'android_studio',
          confidence: 98,
          files: [
            'settings.gradle.kts',
            'build.gradle.kts',
            'app/build.gradle.kts',
            'app/src/main/AndroidManifest.xml',
            'app/src/main/java/com/akkitech/nativeapp/MainActivity.kt'
          ],
          hasIndexHtml: false,
          hasBuildGradle: true,
          hasAndroidManifest: true,
          detectedTitle: 'AKKITECH Native',
          detectedPackage: 'com.akkitech.nativeapp',
          detectedVersion: '1.0.0',
          totalFiles: 5,
          totalSizeBytes: sampleBlob.size,
          summary: 'Android Studio project with Gradle build scripts and Android Manifest detected.'
        });
      }
    } catch (err) {
      console.error('Failed to generate sample', err);
    } finally {
      setIsLoadingSample(false);
    }
  };

  return (
    <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-5 sm:p-6 shadow-xl mb-6">
      
      {/* 2 ZIP Type Selector Tabs */}
      <div className="mb-5">
        <div className="text-xs font-semibold text-slate-400 tracking-wider uppercase mb-2">
          Select Archive Type
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => onChangeProjectType('web_app')}
            className={`p-3.5 rounded-xl border text-left transition-all relative overflow-hidden ${
              activeProjectType === 'web_app'
                ? 'bg-blue-950/60 border-blue-500 shadow-md shadow-blue-500/10'
                : 'bg-slate-950/40 border-white/5 hover:border-white/15'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className={`text-sm font-bold ${activeProjectType === 'web_app' ? 'text-blue-300' : 'text-slate-300'}`}>
                {t.tabWebApp}
              </span>
              {activeProjectType === 'web_app' && (
                <div className="w-2 h-2 rounded-full bg-blue-400" />
              )}
            </div>
            <p className="text-xs text-slate-400 mt-1 line-clamp-2">
              {t.tabWebAppDesc}
            </p>
          </button>

          <button
            type="button"
            onClick={() => onChangeProjectType('android_studio')}
            className={`p-3.5 rounded-xl border text-left transition-all relative overflow-hidden ${
              activeProjectType === 'android_studio'
                ? 'bg-blue-950/60 border-blue-500 shadow-md shadow-blue-500/10'
                : 'bg-slate-950/40 border-white/5 hover:border-white/15'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className={`text-sm font-bold ${activeProjectType === 'android_studio' ? 'text-blue-300' : 'text-slate-300'}`}>
                {t.tabAndroidStudio}
              </span>
              {activeProjectType === 'android_studio' && (
                <div className="w-2 h-2 rounded-full bg-blue-400" />
              )}
            </div>
            <p className="text-xs text-slate-400 mt-1 line-clamp-2">
              {t.tabAndroidStudioDesc}
            </p>
          </button>
        </div>
      </div>

      {/* Main Drag & Drop Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`border-2 border-dashed rounded-xl p-6 sm:p-8 text-center cursor-pointer transition-all ${
          isDragOver
            ? 'border-blue-400 bg-blue-950/40 scale-[0.99]'
            : uploadedFileName
            ? 'border-emerald-500/40 bg-slate-950/60'
            : 'border-white/15 hover:border-blue-500/60 bg-slate-950/40 hover:bg-slate-950/60'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".zip,application/zip,application/x-zip-compressed"
          onChange={handleFileInput}
          className="hidden"
        />

        <div className="flex flex-col items-center justify-center">
          <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-3 transition-colors ${
            uploadedFileName ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'
          }`}>
            {isAnalyzing ? (
              <RefreshCw className="w-7 h-7 animate-spin text-blue-400" />
            ) : uploadedFileName ? (
              <FileArchive className="w-7 h-7" />
            ) : (
              <UploadCloud className="w-7 h-7" />
            )}
          </div>

          {isAnalyzing ? (
            <p className="text-sm font-medium text-blue-300">
              {t.analyzingZip}
            </p>
          ) : uploadedFileName ? (
            <div>
              <p className="text-sm font-bold text-white flex items-center justify-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                {uploadedFileName}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                {detectedInfo ? `${(detectedInfo.totalSizeBytes / 1024).toFixed(1)} KB · ${detectedInfo.totalFiles} ${t.filesFound}` : 'ZIP Loaded'}
              </p>
              <span className="inline-block mt-2 text-xs font-semibold text-blue-400 hover:text-blue-300 underline">
                {t.changeFile}
              </span>
            </div>
          ) : (
            <div>
              <p className="text-sm sm:text-base font-semibold text-white">
                {t.dragDropTitle}
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-md">
                {t.dragDropSubtitle}
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Auto-Detection Banner if File Loaded */}
      {detectedInfo && detectedInfo.type !== 'unknown' && (
        <div className="mt-4 p-4 rounded-xl bg-slate-950/70 border border-blue-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-4 h-4 text-blue-400 shrink-0" />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-blue-300">
                  {t.autoDetectSuccess}:
                </span>
                <span className="text-xs font-semibold text-white bg-blue-900/50 px-2 py-0.5 rounded border border-blue-500/30">
                  {detectedInfo.type === 'web_app' ? 'Web App (HTML/CSS/JS)' : 'Android Studio (Gradle)'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {detectedInfo.summary}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setShowFileList(!showFileList);
            }}
            className="flex items-center gap-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 px-2.5 py-1.5 rounded-lg border border-white/10 shrink-0"
          >
            {showFileList ? t.hideFiles : t.inspectFiles}
            {showFileList ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      )}

      {/* Detected Files List Drawer */}
      {showFileList && detectedInfo && detectedInfo.files.length > 0 && (
        <div className="mt-3 p-3 bg-slate-950 rounded-xl border border-white/10 max-h-48 overflow-y-auto">
          <div className="text-[11px] font-semibold text-slate-400 mb-2">
            Archive Contents Preview ({detectedInfo.totalFiles} files total):
          </div>
          <div className="space-y-1 font-mono text-xs text-slate-300">
            {detectedInfo.files.map((file, idx) => (
              <div key={idx} className="flex items-center gap-2 py-0.5 px-1.5 rounded hover:bg-slate-900">
                <FileText className="w-3 h-3 text-slate-500 shrink-0" />
                <span className="truncate">{file}</span>
              </div>
            ))}
            {detectedInfo.totalFiles > detectedInfo.files.length && (
              <div className="text-slate-500 italic text-[11px] pt-1">
                + {detectedInfo.totalFiles - detectedInfo.files.length} more files...
              </div>
            )}
          </div>
        </div>
      )}

      {/* Quick Test Sample Loaders */}
      <div className="mt-4 pt-4 border-t border-white/5 flex flex-wrap items-center justify-between gap-2">
        <span className="text-xs text-slate-400">
          No ZIP on your phone? Try sample projects:
        </span>
        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={isLoadingSample}
            onClick={() => handleLoadSample('web')}
            className="px-2.5 py-1 text-xs font-medium text-blue-300 hover:text-white bg-blue-950/60 hover:bg-blue-900/60 border border-blue-500/30 rounded-lg transition-colors whitespace-nowrap"
          >
            {t.loadSampleWeb}
          </button>
          <button
            type="button"
            disabled={isLoadingSample}
            onClick={() => handleLoadSample('android')}
            className="px-2.5 py-1 text-xs font-medium text-purple-300 hover:text-white bg-purple-950/60 hover:bg-purple-900/60 border border-purple-500/30 rounded-lg transition-colors whitespace-nowrap"
          >
            {t.loadSampleAndroid}
          </button>
        </div>
      </div>

    </div>
  );
};

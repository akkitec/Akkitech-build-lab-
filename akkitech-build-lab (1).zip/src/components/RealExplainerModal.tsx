import React from 'react';
import { X, ShieldCheck, CheckCircle2, XCircle, Github, Laptop, Smartphone, HelpCircle, ExternalLink } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';

interface RealExplainerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLang: Language;
  onOpenRunnerSetup: () => void;
}

export const RealExplainerModal: React.FC<RealExplainerModalProps> = ({
  isOpen,
  onClose,
  currentLang,
  onOpenRunnerSetup
}) => {
  const t = translations[currentLang];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-blue-500/30 rounded-2xl max-w-2xl w-full p-6 sm:p-7 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-white/10 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  {t.realModalTitle}
                </h3>
                <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/30">
                  {t.realBadge}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {t.realModalSubtitle}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Comparison Section */}
        <div className="space-y-4">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {/* Fake Tools Box */}
            <div className="bg-rose-950/20 border border-rose-500/30 rounded-xl p-4">
              <div className="flex items-center gap-2 text-rose-400 font-bold text-xs mb-2">
                <XCircle className="w-4 h-4 shrink-0" />
                <span>{t.whatFakeToolsDo}</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {t.whatFakeToolsDoDesc}
              </p>
            </div>

            {/* AKKITECH Real Box */}
            <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-xl p-4">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs mb-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{t.whatAkkitechDoes}</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {t.whatAkkitechDoesDesc}
              </p>
            </div>
          </div>

          {/* 4-Step Free APK Guide */}
          <div className="bg-slate-950/80 border border-blue-500/20 rounded-xl p-4 sm:p-5">
            <div className="flex items-center gap-2 text-blue-300 font-bold text-sm mb-3">
              <Smartphone className="w-4 h-4 text-blue-400" />
              <span>{t.stepByStepFreeApkTitle}</span>
            </div>

            <div className="space-y-2.5 text-xs text-slate-300">
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-300 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <span>{t.step1}</span>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-300 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <span>{t.step2}</span>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-blue-600/30 text-blue-300 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  3
                </span>
                <span>{t.step3}</span>
              </div>

              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-emerald-600/30 text-emerald-300 font-bold text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                  4
                </span>
                <span className="text-emerald-200 font-medium">{t.step4}</span>
              </div>
            </div>
          </div>

          {/* Guarantee Note */}
          <div className="p-3.5 bg-blue-950/40 rounded-xl border border-blue-500/20 text-xs text-slate-300 leading-relaxed">
            <strong className="text-blue-300">Engineering Transparency:</strong> We never generate a fake 10KB .apk file that causes errors on your phone. Instead, you get 100% verified native code that compiles into a certified, production-ready Android binary.
          </div>

        </div>

        {/* Footer */}
        <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between">
          <button
            onClick={() => {
              onClose();
              onOpenRunnerSetup();
            }}
            className="text-xs text-blue-400 hover:text-blue-300 font-medium"
          >
            View Cloud Runner Guide &rarr;
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm transition-colors"
          >
            {t.close}
          </button>
        </div>

      </div>
    </div>
  );
};

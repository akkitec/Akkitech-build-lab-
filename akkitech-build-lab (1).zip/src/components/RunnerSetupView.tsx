import React, { useState } from 'react';
import { Wrench, Github, Laptop, Server, Copy, Check, Download, Terminal } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../utils/translations';

interface RunnerSetupViewProps {
  currentLang: Language;
  onDownloadWorkflow: () => void;
}

export const RunnerSetupView: React.FC<RunnerSetupViewProps> = ({
  currentLang,
  onDownloadWorkflow
}) => {
  const t = translations[currentLang];
  const [copiedSnippet, setCopiedSnippet] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSnippet(id);
    setTimeout(() => setCopiedSnippet(null), 2000);
  };

  const dockerCommand = `# Run official Android SDK Build Runner container
docker run -d --name akkitech-runner \\
  -p 8080:8080 \\
  -e ANDROID_HOME=/opt/android-sdk \\
  mingc/android-build-box:latest`;

  const gradleCliCommand = `# Build Debug APK from source folder
./gradlew assembleDebug

# Build Play Store Release AAB
./gradlew bundleRelease`;

  return (
    <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-5 sm:p-7 shadow-xl mb-6">
      <div className="flex items-center gap-2.5 border-b border-white/10 pb-4 mb-6">
        <Wrench className="w-5 h-5 text-blue-400" />
        <div>
          <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
            {t.runnerSetupTitle}
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Architecture guide for compiling real, verifiable Android binaries.
          </p>
        </div>
      </div>

      <div className="space-y-6">

        {/* Option 1: GitHub Actions (Recommended) */}
        <div className="bg-slate-950/80 border border-blue-500/30 rounded-xl p-5">
          <div className="flex items-start justify-between gap-3 mb-2">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
                <Github className="w-5 h-5" />
              </div>
              <h4 className="text-sm sm:text-base font-bold text-white">
                {t.runnerOption1Title}
              </h4>
            </div>
            <button
              onClick={onDownloadWorkflow}
              className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm flex items-center gap-1.5 shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download YAML</span>
            </button>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            {t.runnerOption1Desc}
          </p>
          <div className="mt-3 p-3 bg-slate-900/90 rounded-lg border border-white/5 font-mono text-[11px] text-slate-300 space-y-1">
            <div className="text-slate-400"># Automated step sequence:</div>
            <div>1. git init & git add . & git commit -m "Initial commit"</div>
            <div>2. git push to your GitHub repository</div>
            <div>3. GitHub Actions triggers and compiles using official Temurin JDK 17 & Android SDK</div>
            <div>4. Download APK & AAB from GitHub "Artifacts"</div>
          </div>
        </div>

        {/* Option 2: Android Studio Local GUI */}
        <div className="bg-slate-950/80 border border-white/5 rounded-xl p-5">
          <div className="flex items-center gap-2.5 mb-2">
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
              <Laptop className="w-5 h-5" />
            </div>
            <h4 className="text-sm sm:text-base font-bold text-white">
              {t.runnerOption2Title}
            </h4>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed mb-3">
            {t.runnerOption2Desc}
          </p>
          <div className="relative">
            <pre className="bg-slate-900 p-3 rounded-lg border border-white/5 font-mono text-xs text-slate-300 overflow-x-auto">
              {gradleCliCommand}
            </pre>
            <button
              onClick={() => copyToClipboard(gradleCliCommand, 'gradle')}
              className="absolute top-2 right-2 p-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-white/10"
            >
              {copiedSnippet === 'gradle' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        {/* Option 3: Self-Hosted Docker Build Runner */}
        <div className="bg-slate-950/80 border border-white/5 rounded-xl p-5">
          <div className="flex items-center gap-2.5 mb-2">
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
              <Server className="w-5 h-5" />
            </div>
            <h4 className="text-sm sm:text-base font-bold text-white">
              {t.runnerOption3Title}
            </h4>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed mb-3">
            {t.runnerOption3Desc}
          </p>
          <div className="relative">
            <pre className="bg-slate-900 p-3 rounded-lg border border-white/5 font-mono text-xs text-slate-300 overflow-x-auto">
              {dockerCommand}
            </pre>
            <button
              onClick={() => copyToClipboard(dockerCommand, 'docker')}
              className="absolute top-2 right-2 p-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded border border-white/10"
            >
              {copiedSnippet === 'docker' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

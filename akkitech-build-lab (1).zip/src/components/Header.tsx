import React from 'react';
import { ShieldCheck, Cpu, Globe, Terminal, History, Wrench } from 'lucide-react';
import { Language, EngineStatus } from '../types';
import { translations } from '../utils/translations';

interface HeaderProps {
  currentLang: Language;
  onToggleLang: (lang: Language) => void;
  engineStatus: EngineStatus | null;
  onOpenDiagnostics: () => void;
  onOpenRealExplainer: () => void;
  activeTab: 'build' | 'history' | 'runner';
  onSelectTab: (tab: 'build' | 'history' | 'runner') => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentLang,
  onToggleLang,
  engineStatus,
  onOpenDiagnostics,
  onOpenRealExplainer,
  activeTab,
  onSelectTab
}) => {
  const t = translations[currentLang];
  const isConnected = engineStatus?.connected ?? false;

  return (
    <header className="sticky top-0 z-30 bg-slate-950/90 backdrop-blur-md border-b border-white/10 px-4 sm:px-8 py-3.5 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/20 text-white font-black text-lg tracking-wider">
            A
          </div>
          <div className="flex flex-col">
            <a href="#" onClick={(e) => { e.preventDefault(); onSelectTab('build'); }} className="text-base sm:text-lg font-bold tracking-tight text-white hover:text-blue-400 transition-colors whitespace-nowrap">
              {t.brandName}
            </a>
            <span className="text-[11px] text-slate-400 tracking-wide font-medium">
              {t.brandSubtitle}
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation Links (Clean single-line typography) */}
        <nav className="hidden md:flex items-center gap-6 text-xs sm:text-sm font-medium text-slate-400">
          <button
            onClick={() => onSelectTab('build')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'build'
                ? 'text-blue-400 font-semibold border-b-2 border-blue-500'
                : 'hover:text-slate-200'
            }`}
          >
            {t.navDashboard}
          </button>
          <button
            onClick={() => onSelectTab('history')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'history'
                ? 'text-blue-400 font-semibold border-b-2 border-blue-500'
                : 'hover:text-slate-200'
            }`}
          >
            {t.navHistory}
          </button>
          <button
            onClick={() => onSelectTab('runner')}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeTab === 'runner'
                ? 'text-blue-400 font-semibold border-b-2 border-blue-500'
                : 'hover:text-slate-200'
            }`}
          >
            {t.navRunnerSetup}
          </button>
        </nav>

        {/* Zone 3: Controls (Language Toggle & Engine Status Action) */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Language Switcher */}
          <div className="flex items-center bg-slate-900 border border-white/10 rounded-lg p-0.5">
            <button
              onClick={() => onToggleLang('en')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                currentLang === 'en'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => onToggleLang('hi')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                currentLang === 'hi'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              हिन्दी
            </button>
          </div>

          {/* Real Architecture Info Button */}
          <button
            onClick={onOpenRealExplainer}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-emerald-300 hover:text-emerald-200 bg-emerald-950/40 hover:bg-emerald-950/80 border border-emerald-500/30 rounded-lg transition-colors whitespace-nowrap"
            title="Learn how real Android compilation works"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>{t.isItRealBtn}</span>
          </button>

          {/* Engine Status Diagnostic Button */}
          <button
            onClick={onOpenDiagnostics}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-lg border transition-all whitespace-nowrap shrink-0 ${
              isConnected
                ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300 hover:bg-emerald-900/60'
                : 'bg-amber-950/50 border-amber-500/40 text-amber-300 hover:bg-amber-900/50'
            }`}
            title="Inspect Android SDK & Build Tools connection status"
          >
            <Cpu className={`w-3.5 h-3.5 ${isConnected ? 'text-emerald-400' : 'text-amber-400'}`} />
            <span className="hidden sm:inline">
              {isConnected ? t.engineConnected : t.engineDisconnected}
            </span>
            <span className="sm:hidden">
              {isConnected ? 'Online' : 'Engine Disconnected'}
            </span>
          </button>
        </div>

      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="md:hidden flex items-center justify-around border-t border-white/5 pt-2 mt-2 text-xs font-medium text-slate-400">
        <button
          onClick={() => onSelectTab('build')}
          className={`flex items-center gap-1.5 py-1 ${activeTab === 'build' ? 'text-blue-400 font-bold' : ''}`}
        >
          <Terminal className="w-3.5 h-3.5" />
          <span>{t.navDashboard}</span>
        </button>
        <button
          onClick={() => onSelectTab('history')}
          className={`flex items-center gap-1.5 py-1 ${activeTab === 'history' ? 'text-blue-400 font-bold' : ''}`}
        >
          <History className="w-3.5 h-3.5" />
          <span>{t.navHistory}</span>
        </button>
        <button
          onClick={() => onSelectTab('runner')}
          className={`flex items-center gap-1.5 py-1 ${activeTab === 'runner' ? 'text-blue-400 font-bold' : ''}`}
        >
          <Wrench className="w-3.5 h-3.5" />
          <span>{t.navRunnerSetup}</span>
        </button>
      </div>
    </header>
  );
};

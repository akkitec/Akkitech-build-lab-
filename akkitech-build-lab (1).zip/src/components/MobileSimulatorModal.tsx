import React, { useState, useEffect } from 'react';
import { X, Smartphone, RotateCcw, ArrowLeft, RefreshCw, Maximize2, Shield } from 'lucide-react';
import JSZip from 'jszip';
import { Language } from '../types';
import { translations } from '../utils/translations';

interface MobileSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  sourceZip: JSZip | null;
  appName: string;
  currentLang: Language;
}

export const MobileSimulatorModal: React.FC<MobileSimulatorModalProps> = ({
  isOpen,
  onClose,
  sourceZip,
  appName,
  currentLang
}) => {
  const t = translations[currentLang];
  const [iframeUrl, setIframeUrl] = useState<string | null>(null);
  const [isLandscape, setIsLandscape] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isOpen || !sourceZip) {
      setIframeUrl(null);
      return;
    }

    let urlToRevoke: string | null = null;

    const preparePreview = async () => {
      setLoading(true);
      try {
        // Look for index.html in zip
        let indexPath = '';
        sourceZip.forEach((relativePath) => {
          if (relativePath.toLowerCase().endsWith('index.html') && !indexPath) {
            indexPath = relativePath;
          }
        });

        if (indexPath) {
          const content = await sourceZip.file(indexPath)?.async('text');
          if (content) {
            // Check if there are relative CSS/JS files and inline or bundle
            const blob = new Blob([content], { type: 'text/html' });
            const url = URL.createObjectURL(blob);
            urlToRevoke = url;
            setIframeUrl(url);
          }
        } else {
          const fallbackHtml = `<!DOCTYPE html><html><body style="background:#0a192f;color:#fff;font-family:sans-serif;text-align:center;padding:40px;"><h2>${appName}</h2><p>No index.html found in archive root.</p></body></html>`;
          const blob = new Blob([fallbackHtml], { type: 'text/html' });
          const url = URL.createObjectURL(blob);
          urlToRevoke = url;
          setIframeUrl(url);
        }
      } catch (err) {
        console.error('Failed to create simulator preview', err);
      } finally {
        setLoading(false);
      }
    };

    preparePreview();

    return () => {
      if (urlToRevoke) {
        URL.revokeObjectURL(urlToRevoke);
      }
    };
  }, [isOpen, sourceZip, appName]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-blue-500/30 rounded-2xl max-w-4xl w-full p-4 sm:p-6 shadow-2xl relative flex flex-col max-h-[95vh] overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4 shrink-0">
          <div className="flex items-center gap-2.5">
            <Smartphone className="w-5 h-5 text-blue-400" />
            <div>
              <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
                <span>Android WebView Simulator</span>
                <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                  Live Preview
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Simulating how your web app renders inside an Android smartphone WebView.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsLandscape(!isLandscape)}
              className="p-1.5 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 rounded-lg border border-white/10 flex items-center gap-1"
              title="Rotate Screen"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{isLandscape ? 'Portrait' : 'Landscape'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Smartphone Frame Container */}
        <div className="flex-1 flex items-center justify-center overflow-auto p-2">
          <div
            className={`transition-all duration-300 bg-slate-950 rounded-[36px] border-[10px] border-slate-800 shadow-2xl flex flex-col overflow-hidden relative ${
              isLandscape ? 'w-[640px] h-[360px]' : 'w-[320px] sm:w-[350px] h-[580px] sm:h-[620px]'
            }`}
          >
            {/* Top Phone Speaker & Camera Bezel */}
            <div className="h-6 bg-slate-950 flex items-center justify-between px-6 text-[10px] text-slate-400 select-none shrink-0 border-b border-white/5">
              <span>9:41</span>
              {/* Camera punch hole */}
              <div className="w-3.5 h-3.5 rounded-full bg-slate-900 border border-slate-800 mx-auto" />
              <div className="flex items-center gap-1">
                <span>5G</span>
                <span>100%</span>
              </div>
            </div>

            {/* In-Phone App Title Bar */}
            <div className="bg-slate-900 px-3 py-1.5 flex items-center justify-between border-b border-white/10 text-xs text-white shrink-0">
              <span className="font-semibold truncate max-w-[180px]">{appName}</span>
              <button
                onClick={() => {
                  const ifr = document.getElementById('phone-iframe') as HTMLIFrameElement;
                  if (ifr) ifr.src = ifr.src;
                }}
                className="text-slate-400 hover:text-white"
                title="Reload WebView"
              >
                <RefreshCw className="w-3 h-3" />
              </button>
            </div>

            {/* WebView Viewport */}
            <div className="flex-1 bg-slate-900 relative overflow-hidden">
              {loading ? (
                <div className="absolute inset-0 flex items-center justify-center text-xs text-slate-400">
                  <RefreshCw className="w-5 h-5 animate-spin mr-2 text-blue-400" />
                  Loading WebView assets...
                </div>
              ) : iframeUrl ? (
                <iframe
                  id="phone-iframe"
                  src={iframeUrl}
                  title="Android WebView Preview"
                  className="w-full h-full border-none bg-white"
                  sandbox="allow-scripts allow-same-origin allow-forms allow-modals"
                />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center text-xs text-slate-400">
                  No preview available
                </div>
              )}
            </div>

            {/* Bottom Gesture Navigation Bar */}
            <div className="h-4 bg-slate-950 flex items-center justify-center shrink-0">
              <div className="w-24 h-1 rounded-full bg-slate-700" />
            </div>

          </div>
        </div>

        {/* Footer info */}
        <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between text-xs text-slate-400">
          <span>Target: Android 14 (API 34) WebView</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-semibold rounded-lg text-xs"
          >
            {t.close}
          </button>
        </div>

      </div>
    </div>
  );
};

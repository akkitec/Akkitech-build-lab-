import React from 'react';
import { X, CheckCircle2, Download, Github, Smartphone, FileArchive, AlertTriangle, ArrowRight } from 'lucide-react';
import { BuildJob, Language } from '../types';
import { translations } from '../utils/translations';

interface BuildResultModalProps {
  isOpen: boolean;
  onClose: () => void;
  job: BuildJob | null;
  currentLang: Language;
  onDownloadProjectZip: (job: BuildJob) => void;
  onDownloadWorkflow: () => void;
  onOpenSimulator: () => void;
  onOpenRunnerSetup: () => void;
}

export const BuildResultModal: React.FC<BuildResultModalProps> = ({
  isOpen,
  onClose,
  job,
  currentLang,
  onDownloadProjectZip,
  onDownloadWorkflow,
  onOpenSimulator,
  onOpenRunnerSetup
}) => {
  const t = translations[currentLang];

  if (!isOpen || !job) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-blue-500/40 rounded-2xl max-w-xl w-full p-5 sm:p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-white/10 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 text-blue-400 flex items-center justify-center border border-blue-500/30 shrink-0">
              <CheckCircle2 className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white tracking-tight">
                {currentLang === 'hi' ? 'प्रोजेक्ट पैकेजिंग सफल!' : 'Project Packaged Successfully!'}
              </h3>
              <p className="text-xs text-slate-400">
                {job.appName} · {job.packageId} (Target: {job.targetFormat.toUpperCase()})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Why the APK wasn't compiled on this web server */}
        <div className="mb-4 p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/30 text-xs text-slate-300 leading-relaxed">
          <div className="flex items-center gap-2 text-amber-300 font-bold mb-1">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              {currentLang === 'hi' ? 'सीधे सर्वर पर .apk क्यों नहीं बनी?' : 'Why was .apk not compiled on this server?'}
            </span>
          </div>
          <p>
            {currentLang === 'hi'
              ? 'असली APK बनाने के लिए 15GB का भारी Google Android SDK और Java JDK चाहिए होता है, जो इस लाइटवेट वेब सर्वर में नहीं है। हम आपको कोई नकली या एरर वाली APK नहीं देते। नीचे दिए गए 2 आसान तरीकों से आप असली APK प्राप्त कर सकते हैं:'
              : 'Compiling a real APK requires a 15GB Google Android SDK & JDK 17 compiler daemon, which is not hosted on this lightweight web server. To prevent corrupt or fake APKs, you can get your real binary via the 2 methods below:'}
          </p>
        </div>

        {/* 3 Action Pathways */}
        <div className="space-y-3">
          
          {/* Action 1: Download Complete Source ZIP */}
          <div className="p-4 rounded-xl bg-slate-950 border border-blue-500/30 hover:border-blue-500/60 transition-colors">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className="text-xs font-mono text-blue-400 uppercase tracking-wider font-semibold">
                  {currentLang === 'hi' ? 'तरीका 1: पूरा प्रोजेक्ट डाउनलोड करें' : 'Method 1: Download Complete Project ZIP'}
                </span>
                <h4 className="text-sm font-bold text-white mt-0.5">
                  {t.downloadProjectSource}
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  {currentLang === 'hi'
                    ? '100% असली Kotlin WebView, Gradle स्क्रिप्ट्स और AndroidManifest के साथ। इसे Android Studio में खोलकर Build APK दबाएं।'
                    : 'Complete production-ready project. Open in Android Studio and click Build APK, or compile via Gradle CLI.'}
                </p>
              </div>
            </div>

            <button
              onClick={() => onDownloadProjectZip(job)}
              className="mt-3 w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm rounded-lg shadow-sm flex items-center justify-center gap-2 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>{currentLang === 'hi' ? 'प्रोजेक्ट ZIP अभी डाउनलोड करें' : 'Download Project ZIP Now'}</span>
            </button>
          </div>

          {/* Action 2: Free GitHub Actions Cloud Build */}
          <div className="p-4 rounded-xl bg-slate-950 border border-white/10 hover:border-white/20 transition-colors">
            <div>
              <span className="text-xs font-mono text-emerald-400 uppercase tracking-wider font-semibold">
                {currentLang === 'hi' ? 'तरीका 2: 2-मिनट में मुफ़्त क्लाउड APK (सुझावित)' : 'Method 2: 2-Minute Free Cloud APK (Recommended)'}
              </span>
              <h4 className="text-sm font-bold text-white mt-0.5">
                {currentLang === 'hi' ? 'GitHub Actions से सीधे APK बनाएं' : 'Build via Free GitHub Actions Cloud Runner'}
              </h4>
              <p className="text-xs text-slate-400 mt-1">
                {currentLang === 'hi'
                  ? 'डाउनलोड की गई ZIP को GitHub पर पुश करें। हमने अंदर पहले से .github/workflows/build-apk.yml लगा दिया है। GitHub अपने आप असली Google Android SDK से APK बना देगा!'
                  : 'Push the project to GitHub. GitHub Actions uses official Google Android SDK to build APK & AAB in 2 minutes for free!'}
              </p>
            </div>

            <div className="mt-3 flex items-center gap-2">
              <button
                onClick={onDownloadWorkflow}
                className="flex-1 py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs rounded-lg border border-white/10 flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                <span>Download Workflow YAML</span>
              </button>
              <button
                onClick={() => {
                  onClose();
                  onOpenRunnerSetup();
                }}
                className="py-2 px-3 text-xs text-blue-400 hover:text-blue-300 font-semibold"
              >
                Guide &rarr;
              </button>
            </div>
          </div>

          {/* Action 3: Live Simulator */}
          {job.projectType === 'web_app' && (
            <div className="p-3 bg-slate-950/60 rounded-xl border border-white/5 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <Smartphone className="w-4 h-4 text-purple-400 shrink-0" />
                <span className="text-xs text-slate-300">
                  {currentLang === 'hi' ? 'फोन स्क्रीन में लाइव चलाकर देखना चाहते हैं?' : 'Want to test the app live in phone screen?'}
                </span>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onOpenSimulator();
                }}
                className="px-3 py-1.5 bg-purple-950/80 hover:bg-purple-900 border border-purple-500/30 text-purple-300 text-xs font-semibold rounded-lg shrink-0"
              >
                {currentLang === 'hi' ? 'सिम्युलेटर खोलें' : 'Open Simulator'}
              </button>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="mt-5 pt-3 border-t border-white/10 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold text-slate-400 hover:text-white"
          >
            {t.close}
          </button>
        </div>

      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Terminal, Download, AlertTriangle, CheckCircle2, Copy, Check, FileCode, ArrowRight, Code2, ChevronDown, ChevronUp } from 'lucide-react';
import { BuildJob, Language } from '../types';
import { translations } from '../utils/translations';

interface BuildConsoleProps {
  currentLang: Language;
  job: BuildJob | null;
  onDownloadProjectZip: (job: BuildJob) => void;
  onDownloadWorkflow: () => void;
  onOpenRunnerSetup: () => void;
  onOpenRealExplainer?: () => void;
}

export const BuildConsole: React.FC<BuildConsoleProps> = ({
  currentLang,
  job,
  onDownloadProjectZip,
  onDownloadWorkflow,
  onOpenRunnerSetup,
  onOpenRealExplainer
}) => {
  const t = translations[currentLang];
  const [copied, setCopied] = useState(false);
  const [showCodeInspector, setShowCodeInspector] = useState(false);
  const [activeCodeTab, setActiveCodeTab] = useState<'kotlin' | 'manifest' | 'gradle' | 'workflow'>('kotlin');

  if (!job) return null;

  const handleCopyLogs = () => {
    navigator.clipboard.writeText(job.logs.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isHaltedNoEngine = job.status === 'halted_no_engine';
  const isCompleted = job.status === 'completed';

  // Sample code snippets dynamically tailored to this job
  const kotlinSnippet = `package ${job.packageId}

import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
        }
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.loadUrl("file:///android_asset/www/index.html")
    }
}`;

  const manifestSnippet = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <application
        android:label="${job.appName}"
        android:theme="@style/Theme.AKKITECH"
        android:hardwareAccelerated="true">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const gradleSnippet = `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "${job.packageId}"
    compileSdk = ${job.targetSdk}

    defaultConfig {
        applicationId = "${job.packageId}"
        minSdk = ${job.minSdk}
        targetSdk = ${job.targetSdk}
        versionCode = ${job.versionCode}
        versionName = "${job.versionName}"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.webkit:webkit:1.10.0")
}`;

  const workflowSnippet = `name: AKKITECH Android Build Pipeline
on: [push, workflow_dispatch]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { distribution: 'temurin', java-version: '17' }
      - uses: android-actions/setup-android@v3
      - run: chmod +x gradlew && ./gradlew ${job.targetFormat === 'aab' ? 'bundleRelease' : 'assembleDebug'}
      - uses: actions/upload-artifact@v4
        with:
          name: AKKITECH-${job.targetFormat.toUpperCase()}
          path: app/build/outputs/`;

  return (
    <div className="bg-slate-900/90 border border-white/10 rounded-2xl p-5 sm:p-6 shadow-xl mb-6">
      
      {/* Top Console Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-white/10 pb-4 mb-4">
        <div className="flex items-center gap-2.5">
          <Terminal className="w-5 h-5 text-blue-400" />
          <div>
            <h3 className="text-base font-bold text-white tracking-tight flex items-center gap-2">
              <span>{t.buildConsoleTitle}</span>
              <span className="text-xs font-mono text-slate-400 font-normal">
                ({job.id})
              </span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              Target: {job.targetFormat.toUpperCase()} · {job.packageId}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center">
          <button
            type="button"
            onClick={() => setShowCodeInspector(!showCodeInspector)}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-blue-300 hover:text-white bg-blue-950/60 hover:bg-blue-900/60 rounded-lg border border-blue-500/30 transition-colors"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>{showCodeInspector ? t.hideGeneratedCode : t.previewGeneratedCode}</span>
            {showCodeInspector ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          </button>

          <button
            type="button"
            onClick={handleCopyLogs}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded-lg border border-white/10 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Logs'}</span>
          </button>
        </div>
      </div>

      {/* Terminal Display */}
      <div className="bg-slate-950 rounded-xl p-4 font-mono text-xs text-slate-300 max-h-72 overflow-y-auto space-y-1.5 border border-white/5 leading-relaxed selection:bg-blue-600 selection:text-white">
        {job.logs.map((log, index) => {
          let colorClass = 'text-slate-300';
          if (log.includes('[ERROR]') || log.includes('[FAIL]')) colorClass = 'text-rose-400 font-semibold';
          else if (log.includes('[WARN]') || log.includes('[NOTICE]')) colorClass = 'text-amber-300 font-medium';
          else if (log.includes('[READY]') || log.includes('[SUCCESS]')) colorClass = 'text-emerald-400 font-semibold';
          else if (log.includes('[INIT]') || log.includes('[CONFIG]') || log.includes('[PROJECT]')) colorClass = 'text-blue-300';
          else if (log.includes('[ACTION]')) colorClass = 'text-cyan-300 font-medium';

          return (
            <div key={index} className={colorClass}>
              {log}
            </div>
          );
        })}
      </div>

      {/* Code Inspector Drawer */}
      {showCodeInspector && (
        <div className="mt-4 p-4 rounded-xl bg-slate-950 border border-blue-500/20">
          <div className="flex items-center justify-between mb-3 border-b border-white/5 pb-2">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">
                Real Source Code Preview:
              </span>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setActiveCodeTab('kotlin')}
                className={`px-2 py-1 text-[11px] font-mono rounded ${activeCodeTab === 'kotlin' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
              >
                MainActivity.kt
              </button>
              <button
                onClick={() => setActiveCodeTab('manifest')}
                className={`px-2 py-1 text-[11px] font-mono rounded ${activeCodeTab === 'manifest' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
              >
                AndroidManifest.xml
              </button>
              <button
                onClick={() => setActiveCodeTab('gradle')}
                className={`px-2 py-1 text-[11px] font-mono rounded ${activeCodeTab === 'gradle' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
              >
                build.gradle.kts
              </button>
              <button
                onClick={() => setActiveCodeTab('workflow')}
                className={`px-2 py-1 text-[11px] font-mono rounded ${activeCodeTab === 'workflow' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-white'}`}
              >
                build-apk.yml
              </button>
            </div>
          </div>

          <pre className="p-3 bg-slate-900 rounded-lg text-xs font-mono text-slate-300 overflow-x-auto max-h-56 leading-relaxed">
            {activeCodeTab === 'kotlin' && kotlinSnippet}
            {activeCodeTab === 'manifest' && manifestSnippet}
            {activeCodeTab === 'gradle' && gradleSnippet}
            {activeCodeTab === 'workflow' && workflowSnippet}
          </pre>
        </div>
      )}

      {/* Honest Status Callout */}
      {isHaltedNoEngine && (
        <div className="mt-5 p-4 rounded-xl bg-amber-950/40 border border-amber-500/40">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h4 className="text-sm font-bold text-amber-300">
                  {t.statusHaltedNoEngine}
                </h4>
                {onOpenRealExplainer && (
                  <button
                    onClick={onOpenRealExplainer}
                    className="text-[11px] text-blue-400 hover:text-blue-300 underline font-semibold ml-2"
                  >
                    {t.isItRealBtn} &rarr;
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {t.honestWarningText}
              </p>
              <p className="text-xs text-slate-400">
                Your native Android Studio project is packaged and ready to build on any machine with Android SDK or in GitHub Actions.
              </p>
            </div>
          </div>
        </div>
      )}

      {isCompleted && (
        <div className="mt-5 p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/40 flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <div>
            <h4 className="text-sm font-bold text-emerald-300">
              {t.statusCompleted}
            </h4>
            <p className="text-xs text-slate-300">
              The project pipeline executed successfully and generated binary artifacts.
            </p>
          </div>
        </div>
      )}

      {/* Artifact Download Section */}
      <div className="mt-5 pt-4 border-t border-white/10">
        <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
          Download Artifacts & Source
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          
          {/* Primary Action: Download Ready Android Studio Project ZIP */}
          <button
            type="button"
            onClick={() => onDownloadProjectZip(job)}
            className="p-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-600/20 transition-all flex items-center justify-between text-left group"
          >
            <div>
              <div className="flex items-center gap-2">
                <Download className="w-4 h-4 text-white shrink-0 group-hover:translate-y-0.5 transition-transform" />
                <span>{t.downloadProjectSource}</span>
              </div>
              <p className="text-[11px] text-blue-100 font-normal mt-0.5">
                Ready for Android Studio or Gradle CLI
              </p>
            </div>
            <ArrowRight className="w-4 h-4 opacity-70 group-hover:opacity-100 transition-opacity" />
          </button>

          {/* Secondary Action: Download GitHub Actions Workflow */}
          <button
            type="button"
            onClick={onDownloadWorkflow}
            className="p-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-white/10 text-white font-semibold text-sm transition-all flex items-center justify-between text-left group"
          >
            <div>
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>{t.downloadGithubActions}</span>
              </div>
              <p className="text-[11px] text-slate-400 font-normal mt-0.5">
                Free cloud APK builder for your GitHub repo
              </p>
            </div>
            <ArrowRight className="w-4 h-4 opacity-50 group-hover:opacity-100 transition-opacity" />
          </button>

        </div>

        <div className="mt-3 flex items-center justify-between flex-wrap gap-2">
          {onOpenRealExplainer && (
            <button
              type="button"
              onClick={onOpenRealExplainer}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-medium inline-flex items-center gap-1"
            >
              ⭐ {t.isItRealBtn}
            </button>
          )}

          <button
            type="button"
            onClick={onOpenRunnerSetup}
            className="text-xs text-blue-400 hover:text-blue-300 font-medium inline-flex items-center gap-1"
          >
            Want direct cloud builds? Connect a Build Runner &rarr;
          </button>
        </div>
      </div>

    </div>
  );
};

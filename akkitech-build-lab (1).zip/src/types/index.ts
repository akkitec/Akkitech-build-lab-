export type ProjectType = 'web_app' | 'android_studio';
export type TargetFormat = 'apk_debug' | 'apk_release' | 'aab';
export type Language = 'en' | 'hi';

export interface EngineStatus {
  connected: boolean;
  isLocalReady: boolean;
  remoteWorkerConfigured: boolean;
  workerUrl: string | null;
  tools: {
    jdk: { installed: boolean; version: string };
    androidSdk: { installed: boolean; path: string };
    gradle: { installed: boolean; version: string };
  };
  statusSummary: string;
  recommendation: string;
}

export interface BuildConfig {
  appName: string;
  packageId: string;
  versionName: string;
  versionCode: number;
  minSdk: number;
  targetSdk: number;
  projectType: ProjectType;
  targetFormat: TargetFormat;
  orientation: 'unspecified' | 'portrait' | 'landscape';
  permissions: string[];
  pullToRefresh: boolean;
  enableOfflineCache: boolean;
  allowFileUploads: boolean;
  allowCamera: boolean;
  enableDeepLinks: boolean;
  hardwareAcceleration: boolean;
}

export interface DetectedProjectInfo {
  type: ProjectType | 'unknown';
  confidence: number;
  files: string[];
  hasIndexHtml: boolean;
  hasBuildGradle: boolean;
  hasAndroidManifest: boolean;
  detectedTitle?: string;
  detectedPackage?: string;
  detectedVersion?: string;
  totalFiles: number;
  totalSizeBytes: number;
  summary: string;
}

export interface BuildJob {
  id: string;
  createdAt: number;
  appName: string;
  packageId: string;
  versionName: string;
  versionCode: number;
  projectType: ProjectType;
  targetFormat: TargetFormat;
  status: 'queued' | 'validating' | 'packaging' | 'halted_no_engine' | 'completed' | 'failed';
  statusMessage: string;
  zipName: string;
  zipSize: number;
  detectedFilesCount: number;
  logs: string[];
  runnerConnected: boolean;
  minSdk: number;
  targetSdk: number;
  generatedProjectBlob?: Blob;
  generatedProjectFileName?: string;
}

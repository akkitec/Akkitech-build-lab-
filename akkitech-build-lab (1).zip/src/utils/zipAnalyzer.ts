import JSZip from 'jszip';
import { DetectedProjectInfo, ProjectType } from '../types';

export async function analyzeZipFile(fileOrBuffer: File | Blob | ArrayBuffer): Promise<{
  zip: JSZip;
  detectedInfo: DetectedProjectInfo;
}> {
  const zip = new JSZip();
  const loadedZip = await zip.loadAsync(fileOrBuffer);

  const filePaths: string[] = [];
  let totalSizeBytes = 0;
  let hasIndexHtml = false;
  let hasBuildGradle = false;
  let hasAndroidManifest = false;
  let indexHtmlPath = '';
  let manifestPath = '';
  let gradlePath = '';

  loadedZip.forEach((relativePath, zipEntry) => {
    filePaths.push(relativePath);
    if (!zipEntry.dir) {
      // Estimate size if available
      // @ts-ignore
      totalSizeBytes += zipEntry._data?.uncompressedSize || 1024;
    }

    const lower = relativePath.toLowerCase();
    if (lower.endsWith('index.html') && !hasIndexHtml) {
      hasIndexHtml = true;
      indexHtmlPath = relativePath;
    }
    if ((lower.endsWith('build.gradle') || lower.endsWith('build.gradle.kts') || lower.endsWith('settings.gradle') || lower.endsWith('settings.gradle.kts')) && !hasBuildGradle) {
      hasBuildGradle = true;
      gradlePath = relativePath;
    }
    if (lower.endsWith('androidmanifest.xml') && !hasAndroidManifest) {
      hasAndroidManifest = true;
      manifestPath = relativePath;
    }
  });

  let detectedTitle = '';
  let detectedPackage = '';
  let detectedVersion = '1.0.0';

  // Read index.html for title if present
  if (hasIndexHtml && indexHtmlPath) {
    try {
      const indexContent = await loadedZip.file(indexHtmlPath)?.async('text');
      if (indexContent) {
        const titleMatch = indexContent.match(/<title[^>]*>([^<]+)<\/title>/i);
        if (titleMatch && titleMatch[1].trim()) {
          detectedTitle = titleMatch[1].trim();
        }
      }
    } catch {
      // Ignore parse failure
    }
  }

  // Read AndroidManifest or build.gradle for package info if present
  if (hasAndroidManifest && manifestPath) {
    try {
      const manifestContent = await loadedZip.file(manifestPath)?.async('text');
      if (manifestContent) {
        const pkgMatch = manifestContent.match(/package\s*=\s*["']([^"']+)["']/i);
        if (pkgMatch && pkgMatch[1]) {
          detectedPackage = pkgMatch[1].trim();
        }
      }
    } catch {
      // Ignore
    }
  }

  if (hasBuildGradle && gradlePath && !detectedPackage) {
    try {
      const gradleContent = await loadedZip.file(gradlePath)?.async('text');
      if (gradleContent) {
        const appIdMatch = gradleContent.match(/applicationId\s*=?\s*["']([^"']+)["']/i) || gradleContent.match(/namespace\s*=?\s*["']([^"']+)["']/i);
        if (appIdMatch && appIdMatch[1]) {
          detectedPackage = appIdMatch[1].trim();
        }
        const vNameMatch = gradleContent.match(/versionName\s*=?\s*["']([^"']+)["']/i);
        if (vNameMatch && vNameMatch[1]) {
          detectedVersion = vNameMatch[1].trim();
        }
      }
    } catch {
      // Ignore
    }
  }

  // Determine Project Type & Confidence
  let projectType: ProjectType | 'unknown' = 'unknown';
  let confidence = 50;
  let summary = '';

  if (hasBuildGradle || hasAndroidManifest) {
    projectType = 'android_studio';
    confidence = hasBuildGradle && hasAndroidManifest ? 98 : 88;
    summary = 'Android Studio project with Gradle build scripts and Android Manifest detected.';
  } else if (hasIndexHtml) {
    projectType = 'web_app';
    confidence = 95;
    summary = `Web Application detected with entry point "${indexHtmlPath}".`;
  } else {
    // Check if web assets exist
    const hasWebAssets = filePaths.some(p => /\.(js|css|html|json|png|jpg|svg)$/i.test(p));
    if (hasWebAssets) {
      projectType = 'web_app';
      confidence = 65;
      summary = 'Web assets detected without a standard index.html entry point.';
    } else {
      projectType = 'unknown';
      confidence = 20;
      summary = 'Unknown archive structure. Please check the ZIP contents.';
    }
  }

  return {
    zip: loadedZip,
    detectedInfo: {
      type: projectType,
      confidence,
      files: filePaths.slice(0, 30),
      hasIndexHtml,
      hasBuildGradle,
      hasAndroidManifest,
      detectedTitle: detectedTitle || undefined,
      detectedPackage: detectedPackage || undefined,
      detectedVersion: detectedVersion || '1.0.0',
      totalFiles: filePaths.length,
      totalSizeBytes: totalSizeBytes || 1024,
      summary
    }
  };
}

/**
 * Generates an instant, working sample Web App ZIP for testing
 */
export async function createSampleWebAppZip(): Promise<Blob> {
  const sampleZip = new JSZip();

  const sampleHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AKKITECH Nova</title>
  <style>
    body {
      font-family: system-ui, -apple-system, sans-serif;
      background: #0f172a;
      color: #f8fafc;
      margin: 0;
      padding: 24px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      text-align: center;
      box-sizing: border-box;
    }
    .card {
      background: #1e293b;
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 16px;
      padding: 32px;
      max-width: 400px;
      width: 100%;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5);
    }
    h1 { color: #38bdf8; margin-top: 0; font-size: 24px; }
    p { color: #94a3b8; font-size: 14px; line-height: 1.6; }
    button {
      background: #2563eb;
      color: white;
      border: none;
      padding: 12px 24px;
      border-radius: 8px;
      font-weight: 600;
      font-size: 15px;
      cursor: pointer;
      margin-top: 16px;
      transition: background 0.2s;
      width: 100%;
    }
    button:active { background: #1d4ed8; }
    .counter { font-size: 32px; font-weight: bold; color: #60a5fa; margin: 16px 0; }
  </style>
</head>
<body>
  <div class="card">
    <h1>AKKITECH Nova Web App</h1>
    <p>This is a fast, responsive HTML5 mobile web app converted into an Android WebView project.</p>
    <div class="counter" id="count">0</div>
    <button onclick="increment()">Tap to Count</button>
  </div>
  <script>
    let c = 0;
    function increment() {
      c++;
      document.getElementById('count').innerText = c;
      if (window.navigator && window.navigator.vibrate) {
        window.navigator.vibrate(50);
      }
    }
  </script>
</body>
</html>`;

  sampleZip.file('index.html', sampleHtml);
  sampleZip.file('app.css', '/* AKKITECH Nova Mobile Stylesheet */\nbody { touch-action: manipulation; }');
  sampleZip.file('manifest.json', JSON.stringify({
    name: 'AKKITECH Nova',
    short_name: 'Nova',
    start_url: './index.html',
    display: 'standalone',
    background_color: '#0f172a',
    theme_color: '#1e3a8a'
  }, null, 2));

  return await sampleZip.generateAsync({ type: 'blob' });
}

/**
 * Generates an instant, working sample Android Studio Gradle Project ZIP for testing
 */
export async function createSampleAndroidProjectZip(): Promise<Blob> {
  const sampleZip = new JSZip();

  sampleZip.file('settings.gradle.kts', `rootProject.name = "AKKITECHNative"
include(":app")
`);

  sampleZip.file('build.gradle.kts', `// Top-level build file
plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
`);

  sampleZip.file('app/build.gradle.kts', `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.akkitech.nativeapp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.akkitech.nativeapp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}
`);

  sampleZip.file('app/src/main/AndroidManifest.xml', `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="AKKITECH Native"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.Light.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`);

  sampleZip.file('app/src/main/java/com/akkitech/nativeapp/MainActivity.kt', `package com.akkitech.nativeapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}
`);

  return await sampleZip.generateAsync({ type: 'blob' });
}

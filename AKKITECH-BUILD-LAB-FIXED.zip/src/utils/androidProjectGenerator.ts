import JSZip from 'jszip';
import { BuildConfig, TargetFormat } from '../types';

export async function generateAndroidStudioProjectZip(
  sourceZip: JSZip | null,
  config: BuildConfig,
  isAndroidStudioInput: boolean = false
): Promise<Blob> {
  const projectZip = new JSZip();

  // If user uploaded an existing Android Studio project, we preserve its files and inject/update configs
  if (isAndroidStudioInput && sourceZip) {
    sourceZip.forEach((relativePath, fileEntry) => {
      if (!fileEntry.dir) {
        projectZip.file(relativePath, fileEntry.async('arraybuffer'));
      }
    });

    // Add GitHub Actions workflow helper if not present
    projectZip.file(
      '.github/workflows/build-apk.yml',
      generateGitHubActionsWorkflow(config.targetFormat, config.appName)
    );

    projectZip.file(
      'AKKITECH_BUILD_INSTRUCTIONS.md',
      generateBuildInstructions(config)
    );

    return await projectZip.generateAsync({
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 }
    });
  }

  // --- TYPE 1: Convert HTML/CSS/JS Web App into Production Native Android Studio Project ---
  const packagePath = config.packageId.replace(/\./g, '/');

  // 1. Root settings.gradle.kts
  projectZip.file(
    'settings.gradle.kts',
    `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "${config.appName.replace(/[^a-zA-Z0-9_-]/g, '_')}"
include(":app")
`
  );

  // 2. Root build.gradle.kts
  projectZip.file(
    'build.gradle.kts',
    `// AKKITECH BUILD LAB Generated Project
plugins {
    id("com.android.application") version "8.6.1" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}

tasks.register("clean", Delete::class) {
    delete(rootProject.layout.buildDirectory)
}
`
  );

  // 3. Root gradle.properties
  projectZip.file(
    'gradle.properties',
    `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official
`
  );

  // 5. app/build.gradle.kts
  projectZip.file(
    'app/build.gradle.kts',
    `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "${config.packageId}"
    compileSdk = ${config.targetSdk}

    defaultConfig {
        applicationId = "${config.packageId}"
        minSdk = ${config.minSdk}
        targetSdk = ${config.targetSdk}
        versionCode = ${config.versionCode}
        versionName = "${config.versionName}"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        debug {
            isDebuggable = true
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug") // Defaults to debug signature until production keystore configured
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.webkit:webkit:1.10.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
}
`
  );

  // 6. app/proguard-rules.pro
  projectZip.file(
    'app/proguard-rules.pro',
    `# AKKITECH Webview ProGuard Rules
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class android.webkit.** { *; }
`
  );

  // 7. Permissions XML
  const permSet = new Set(config.permissions);
  if (config.allowCamera) permSet.add('android.permission.CAMERA');
  if (config.allowFileUploads) permSet.add('android.permission.READ_EXTERNAL_STORAGE');
  permSet.add('android.permission.INTERNET');
  permSet.add('android.permission.ACCESS_NETWORK_STATE');

  const permissionsXml = Array.from(permSet)
    .map(p => `    <uses-permission android:name="${p.startsWith('android.permission.') ? p : 'android.permission.' + p}" />`)
    .join('\n');

  // Screen orientation attribute
  const orientationAttr =
    config.orientation === 'portrait'
      ? 'android:screenOrientation="portrait"'
      : config.orientation === 'landscape'
      ? 'android:screenOrientation="landscape"'
      : 'android:screenOrientation="unspecified"';

  // 8. app/src/main/AndroidManifest.xml
  projectZip.file(
    'app/src/main/AndroidManifest.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

${permissionsXml}

    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@drawable/ic_launcher"
        android:supportsRtl="true"
        android:theme="@style/Theme.AKKITECH"
        android:hardwareAccelerated="${config.hardwareAcceleration}"
        android:usesCleartextTraffic="true"
        tools:targetApi="34">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            ${orientationAttr}
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>

    </application>
</manifest>
`
  );

  // 9. Kotlin MainActivity.kt
  projectZip.file(
    `app/src/main/java/${packagePath}/MainActivity.kt`,
    `package ${config.packageId}

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.*
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var swipeRefresh: SwipeRefreshLayout? = null
    private lateinit var progressBar: ProgressBar
    private lateinit var offlineContainer: FrameLayout
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
            fileUploadCallback?.onReceiveValue(uris)
        } else {
            fileUploadCallback?.onReceiveValue(null)
        }
        fileUploadCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        offlineContainer = findViewById(R.id.offlineContainer)
        ${config.pullToRefresh ? 'swipeRefresh = findViewById(R.id.swipeRefresh)' : ''}

        configureWebView()
        setupBackNavigation()

        ${config.pullToRefresh ? `
        swipeRefresh?.setOnRefreshListener {
            webView.reload()
        }
        swipeRefresh?.setColorSchemeResources(R.color.akkitech_blue)
        ` : ''}

        val btnRetry = findViewById<View>(R.id.btnRetry)
        btnRetry?.setOnClickListener {
            offlineContainer.visibility = View.GONE
            webView.visibility = View.VISIBLE
            webView.reload()
        }

        // Load local bundled web assets
        loadLocalApp()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        ${config.enableOfflineCache ? 'settings.cacheMode = WebSettings.LOAD_DEFAULT' : 'settings.cacheMode = WebSettings.LOAD_NO_CACHE'}

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                ${config.pullToRefresh ? 'swipeRefresh?.isRefreshing = false' : ''}
            }

            override fun onReceivedError(
                view: WebView?,
                errorCode: Int,
                description: String?,
                failingUrl: String?
            ) {
                super.onReceivedError(view, errorCode, description, failingUrl)
                showOfflineScreen()
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                ${config.enableDeepLinks ? `
                if (url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("whatsapp:") || url.startsWith("sms:")) {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        startActivity(intent)
                        return true
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(this@MainActivity, "Application not installed", Toast.LENGTH_SHORT).show()
                        return true
                    }
                }
                ` : ''}
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress >= 100) {
                    progressBar.visibility = View.GONE
                }
            }

            override fun onShowFileChooser(
                mWebView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                ${config.allowFileUploads ? `
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                try {
                    val intent = fileChooserParams?.createIntent()
                    if (intent != null) {
                        filePickerLauncher.launch(intent)
                        return true
                    }
                } catch (e: Exception) {
                    fileUploadCallback = null
                    return false
                }
                ` : 'return false'}
                return false
            }
        }
    }

    private fun loadLocalApp() {
        webView.loadUrl("file:///android_asset/www/index.html")
    }

    private fun showOfflineScreen() {
        webView.visibility = View.GONE
        offlineContainer.visibility = View.VISIBLE
        ${config.pullToRefresh ? 'swipeRefresh?.isRefreshing = false' : ''}
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }
}
`
  );

  // 10. app/src/main/res/layout/activity_main.xml
  projectZip.file(
    'app/src/main/res/layout/activity_main.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#0A192F">

    ${config.pullToRefresh ? `
    <androidx.swiperefreshlayout.widget.SwipeRefreshLayout
        android:id="@+id/swipeRefresh"
        android:layout_width="match_parent"
        android:layout_height="match_parent">

        <WebView
            android:id="@+id/webView"
            android:layout_width="match_parent"
            android:layout_height="match_parent" />

    </androidx.swiperefreshlayout.widget.SwipeRefreshLayout>
    ` : `
    <WebView
        android:id="@+id/webView"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
    `}

    <ProgressBar
        android:id="@+id/progressBar"
        style="?android:attr/progressBarStyleHorizontal"
        android:layout_width="match_parent"
        android:layout_height="4dp"
        android:layout_gravity="top"
        android:indeterminate="false"
        android:max="100"
        android:progressTint="#38BDF8"
        android:visibility="gone" />

    <FrameLayout
        android:id="@+id/offlineContainer"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:background="#0A192F"
        android:padding="32dp"
        android:visibility="gone">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_gravity="center"
            android:gravity="center"
            android:orientation="vertical">

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Connection Offline"
                android:textColor="#38BDF8"
                android:textSize="22sp"
                android:textStyle="bold" />

            <TextView
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginTop="8dp"
                android:gravity="center"
                android:text="Please check your network connection and retry."
                android:textColor="#94A3B8"
                android:textSize="14sp" />

            <Button
                android:id="@+id/btnRetry"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginTop="20dp"
                android:backgroundTint="#2563EB"
                android:paddingStart="24dp"
                android:paddingEnd="24dp"
                android:text="Retry"
                android:textColor="#FFFFFF" />

        </LinearLayout>

    </FrameLayout>

</FrameLayout>
`
  );

  // 11. Resources: strings.xml, colors.xml, themes.xml, file_paths.xml
  projectZip.file(
    'app/src/main/res/values/strings.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${config.appName}</string>
</resources>
`
  );

  projectZip.file(
    'app/src/main/res/values/colors.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="akkitech_navy">#0A192F</color>
    <color name="akkitech_blue">#2563EB</color>
    <color name="akkitech_cyan">#38BDF8</color>
    <color name="white">#FFFFFFFF</color>
</resources>
`
  );

  projectZip.file(
    'app/src/main/res/values/themes.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.AKKITECH" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="colorPrimary">@color/akkitech_blue</item>
        <item name="colorPrimaryVariant">@color/akkitech_navy</item>
        <item name="colorOnPrimary">@color/white</item>
        <item name="android:statusBarColor">@color/akkitech_navy</item>
        <item name="android:windowBackground">@color/akkitech_navy</item>
    </style>
</resources>
`
  );

  projectZip.file(
    'app/src/main/res/xml/file_paths.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<paths>
    <external-path name="my_images" path="Android/data/${config.packageId}/files/Pictures" />
    <cache-path name="cache" path="." />
</paths>
`
  );

  // Vector launcher icon: no missing mipmap resources and works from minSdk 24.
  projectZip.file(
    'app/src/main/res/drawable/ic_launcher.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="48dp" android:height="48dp" android:viewportWidth="48" android:viewportHeight="48">
    <path android:fillColor="#0A192F" android:pathData="M0,0h48v48h-48z" />
    <path android:fillColor="#38BDF8" android:pathData="M9,34V14h5l10,12 10,-12h5v20h-5V21L24,32 14,21v13z" />
</vector>
`
  );

  // 12. Bundling Web Assets into `app/src/main/assets/www/`
  if (sourceZip) {
    // Find if files are inside a subfolder or root
    const allPaths: string[] = [];
    sourceZip.forEach(p => allPaths.push(p));

    let commonPrefix = '';
    const indexEntry = allPaths.find(p => p.toLowerCase().endsWith('index.html'));
    if (indexEntry && indexEntry.includes('/')) {
      commonPrefix = indexEntry.substring(0, indexEntry.lastIndexOf('/') + 1);
    }

    sourceZip.forEach((relativePath, fileEntry) => {
      if (!fileEntry.dir) {
        let destPath = relativePath;
        if (commonPrefix && relativePath.startsWith(commonPrefix)) {
          destPath = relativePath.substring(commonPrefix.length);
        }
        projectZip.file(`app/src/main/assets/www/${destPath}`, fileEntry.async('arraybuffer'));
      }
    });
  } else {
    // Default fallback index.html
    projectZip.file(
      'app/src/main/assets/www/index.html',
      `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>${config.appName}</title></head>
<body style="background:#0a192f;color:#fff;font-family:sans-serif;text-align:center;padding:50px;">
  <h1>${config.appName}</h1>
  <p>Ready to run on Android WebView</p>
</body>
</html>`
    );
  }

  // 13. GitHub Actions CI/CD Workflow (.github/workflows/build-apk.yml)
  projectZip.file(
    '.github/workflows/build-apk.yml',
    generateGitHubActionsWorkflow(config.targetFormat, config.appName)
  );

  // 14. Detailed Readme & instructions
  projectZip.file(
    'README.md',
    generateBuildInstructions(config)
  );

  return await projectZip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 }
  });
}

function generateGitHubActionsWorkflow(targetFormat: TargetFormat, appName: string): string {
  const isAab = targetFormat === 'aab';
  const gradleTask = isAab ? 'bundleRelease' : targetFormat === 'apk_release' ? 'assembleRelease' : 'assembleDebug';
  const artifactName = `${appName.replace(/[^a-zA-Z0-9_-]/g, '_')}-${isAab ? 'AppBundle' : 'APK'}`;
  const artifactPath = isAab
    ? 'app/build/outputs/bundle/**/*.aab'
    : 'app/build/outputs/apk/**/*.apk';

  return `name: AKKITECH Android Build Pipeline

on:
  workflow_dispatch:
  push:
    branches: [ main, master ]

permissions:
  contents: read

jobs:
  build:
    name: Compile Android ${isAab ? 'AAB Bundle' : 'APK'}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout source
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Install Gradle 8.7
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.7'

      - name: Accept Android SDK licenses
        run: yes | sdkmanager --licenses || true

      - name: Build ${isAab ? 'AAB' : 'APK'}
        run: gradle ${gradleTask} --no-daemon --stacktrace

      - name: Upload compiled artifact
        uses: actions/upload-artifact@v4
        with:
          name: ${artifactName}
          path: ${artifactPath}
          if-no-files-found: error
          retention-days: 14
`;
}

function generateBuildInstructions(config: BuildConfig): string {
  return `# ${config.appName} - Android Studio Native Project
Generated by **AKKITECH BUILD LAB by AKKITECH**

Application ID: \`${config.packageId}\`  
Version Name: \`${config.versionName}\` (Code: \`${config.versionCode}\`)  
Min SDK: \`${config.minSdk}\` | Target SDK: \`${config.targetSdk}\`

---

## 🚀 How to Build APK or AAB

### Method 1: 1-Click Free GitHub Actions Build (Recommended)
1. Initialize a Git repository in this folder and push to GitHub (public or private).
2. Go to your GitHub repository -> **Actions** tab.
3. Select **AKKITECH Android Build Pipeline** and tap **Run workflow**. A push to `main` or `master` also starts it.
4. Wait for the green check, open the completed run, and download the compiled file from **Artifacts**.

### Method 2: Build Locally using Android Studio
1. Open Android Studio on your computer.
2. Click **Open** and select this extracted project folder.
3. Allow Gradle to sync dependencies.
4. Go to **Build** menu:
   - For APK: Click **Build Bundle(s) / APK(s)** -> **Build APK(s)**
   - For Play Store AAB: Click **Build Bundle(s) / APK(s)** -> **Build Bundle(s)**
5. Output file will be located at \`app/build/outputs/apk/\` or \`app/build/outputs/bundle/\`.

### Method 3: Command Line (CLI)
\`\`\`bash
# On Linux/macOS
gradle ${config.targetFormat === 'aab' ? 'bundleRelease' : config.targetFormat === 'apk_release' ? 'assembleRelease' : 'assembleDebug'}

# On Windows PowerShell/CMD
gradle ${config.targetFormat === 'aab' ? 'bundleRelease' : config.targetFormat === 'apk_release' ? 'assembleRelease' : 'assembleDebug'}
\`\`\`

---
© AKKITECH. Professional Android Build System.
`;
}

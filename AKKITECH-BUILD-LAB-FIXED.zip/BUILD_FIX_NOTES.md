# AKKITECH BUILD LAB - Fix Notes

This update repairs the Android project generator and the downloadable GitHub Actions workflow.

- Uses Android Gradle Plugin 8.6.1, Kotlin 1.9.24, and Gradle 8.7 (compatible with compileSdk 35).
- Removes the incomplete Gradle wrapper setup; GitHub Actions installs Gradle 8.7 explicitly.
- Adds a vector launcher icon so the generated manifest does not reference missing icon resources.
- Makes GitHub Actions build with `gradle` and fail clearly if the APK/AAB artifact is missing.
- Corrects the build instructions to tell users to run the workflow from the Actions tab.
- Prevents the web interface from reporting a successful binary build when it has only generated a source project ZIP and no real build-dispatch endpoint is configured.

Important: This ZIP is the AKKITECH BUILD LAB web-app source code. It is not itself an APK, and the generated Android project still needs to be compiled by GitHub Actions. The Android build has not been run in this environment.
